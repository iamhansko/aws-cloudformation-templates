# -*- coding: utf-8 -*-


################################################################################
# Exceptions
################################################################################

class NotHangulException(Exception):
    pass


class NotLetterException(Exception):
    pass


class NotWordException(Exception):
    pass
